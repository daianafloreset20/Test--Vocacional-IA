// ==========================================
// 1. VERIFICACIÓN DE DATOS DESDE LOCALSTORAGE
// ==========================================

const nombre = localStorage.getItem("nombreGuardado") || "Estudiante";

const respuestasRaw = localStorage.getItem("respuestasGuardadas");

if (!respuestasRaw) {
    alert("No encontramos respuestas registradas. Te redirigimos al inicio.");
    window.location.href = "index.html";
}

const respuestas = JSON.parse(respuestasRaw) || [];

const elementoSaludo = document.getElementById("saludo");
const elementoHero = document.getElementById("hero-resultados");
const elementoAcciones = document.getElementById("acciones-resultados");
const elementoBotonImprimir = document.getElementById("btn-imprimir");

if (elementoSaludo) {
    elementoSaludo.innerText = "¡Hola, " + nombre + "!";
}

// ==========================================
// ESTADO INICIAL DE LA PÁGINA
// Primero se muestra solamente "Analizando...".
// ==========================================

if (elementoHero) {
    elementoHero.style.display = "none";
}

if (elementoAcciones) {
    elementoAcciones.style.display = "none";
}

if (elementoBotonImprimir) {
    elementoBotonImprimir.style.display = "none";
}


// ==========================================
// 2. CONFIGURACIÓN DE LA API DE GROQ CLOUD
// ==========================================

const GROQ_API_KEY = "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";


// ==========================================
// 3. PROMPT DE ORIENTACIÓN VOCACIONAL
// ==========================================

const promptText = `

Actúa como orientador vocacional para un estudiante de Argentina.

Nombre del estudiante: ${nombre}

Respuestas del test:

${JSON.stringify(respuestas)}

Genera únicamente la respuesta final. No muestres razonamientos, análisis internos, pasos de pensamiento, verificaciones ni explicaciones sobre cómo generaste la respuesta.

REGLAS:

- Responde exclusivamente en español.
- No escribas nada en inglés.
- No saludes.
- No repitas las instrucciones.
- No expliques el proceso de análisis.
- Sé breve y claro.
- Usa exactamente la estructura indicada.

FORMATO:

### 1. Perfil Vocacional y Fortalezas

Escribe 2 líneas breves describiendo sus principales fortalezas vocacionales.

### 2. Carreras Recomendadas

Recomienda exactamente 3 carreras relacionadas con las respuestas del estudiante.

Para cada carrera utiliza este formato:

Nombre oficial completo de la carrera.

Breve explicación de por qué es adecuada para el perfil del estudiante.

No utilices guiones, asteriscos, viñetas ni numeración.

Cada nombre de carrera debe terminar con un punto.

Cada explicación debe terminar con un punto.

Deja una línea en blanco entre cada carrera.

Utiliza siempre el nombre oficial y completo de la carrera, evitando abreviaciones o nombres incorrectos.

### 3. Dónde Estudiar en Argentina

Recomienda exactamente 3 universidades o instituciones universitarias ubicadas en Ciudad de Buenos Aires o Gran Buenos Aires y relacionadas con las carreras recomendadas.

Para cada universidad utiliza exactamente este formato:

Nombre completo de la universidad (sigla).

Ubicación: ciudad y sede, campus o zona cuando sea posible.

Por qué estudiarla: explicación breve de por qué es una buena opción para las carreras recomendadas y el perfil del estudiante.

No utilices guiones, asteriscos, viñetas ni numeración.

Cada nombre de universidad debe terminar con un punto.

La ubicación debe terminar con un punto.

La explicación de por qué estudiarla debe terminar con un punto.

Deja una línea en blanco entre cada universidad.

Prioriza instituciones reconocidas de Ciudad de Buenos Aires y Gran Buenos Aires.

Elige las universidades según las carreras recomendadas y evita repetir siempre las mismas.

`;


// ==========================================
// 4. FUNCIÓN PARA CONSULTAR A GROQ CLOUD
// ==========================================

async function consultarGroq() {

    const URL = "https://api.groq.com/openai/v1/chat/completions";

    try {

        const response = await fetch(URL, {
            method: "POST",

            headers: {
                "Authorization": `Bearer ${GROQ_API_KEY}`,
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                model: "qwen/qwen3.8-27b",

                messages: [
                    {
                        role: "user",
                        content: promptText
                    }
                ],

              temperature: 0.7,
reasoning_effort: "none",
max_completion_tokens: 900
            })
        });


        // ==========================================
        // VERIFICACIÓN DEL RESULTADO
        // ==========================================

        if (!response.ok) {

            const errorDetalle = await response.text();

            console.error(
                "Detalle exacto del error:",
                errorDetalle
            );

            throw new Error(`Error ${response.status}`);
        }


        // ==========================================
        // PROCESAR RESPUESTA DE GROQ
        // ==========================================

        const data = await response.json();

        const textoRespuesta =
            data.choices?.[0]?.message?.content;


        if (!textoRespuesta) {
            throw new Error("Groq no devolvió contenido.");
        }


        mostrarResultado(textoRespuesta);


    } catch (error) {

        console.error(
            "Fallo la conexión con la IA:",
            error
        );

        mostrarError();
    }
}


// ==========================================
// 5. FORMATEADOR VISUAL DEL RESULTADO
// SOLO CAMBIOS DE DISEÑO / PRESENTACIÓN
// ==========================================

function mostrarResultado(textoMarkdown) {

    const cargandoResultado = document.getElementById("cargando");

    if (cargandoResultado) {
        cargandoResultado.style.display = "none";
    }

    if (elementoHero) {
        elementoHero.style.display = "flex";
    }

    const texto = textoMarkdown
        .replace(/\r/g, "")
        .replace(/\*\*/g, "")
        .trim();

    const partes = texto.split(/###\s*/);

    let perfilTexto = "";
    let carrerasTexto = "";
    let universidadesTexto = "";

    partes.forEach(parte => {

        const contenido = parte.trim();

        if (contenido.startsWith("1.")) {
            perfilTexto = contenido
                .replace(/^1\.\s*Perfil Vocacional y Fortalezas\s*/i, "")
                .trim();
        }

        if (contenido.startsWith("2.")) {
            carrerasTexto = contenido
                .replace(/^2\.\s*Carreras Recomendadas\s*/i, "")
                .trim();
        }

        if (contenido.startsWith("3.")) {
            universidadesTexto = contenido
                .replace(/^3\.\s*Dónde Estudiar en Argentina\s*/i, "")
                .trim();
        }
    });

    let html = "";

    // ==========================================
    // 1. PERFIL VOCACIONAL
    // ==========================================

    html += `
        <section class="resultado-bloque perfil-bloque">

            <div class="bloque-cabecera">
                <div class="bloque-numero">1</div>

                <div>
                    <span class="bloque-etiqueta">TU PERFIL</span>
                    <h3>Perfil Vocacional y Fortalezas</h3>
                </div>
            </div>

            <div class="perfil-contenido">
                <div class="perfil-icono">✦</div>
                <p>${perfilTexto}</p>
            </div>
        </section>
    `;

    // ==========================================
    // 2. CARRERAS RECOMENDADAS
    // SIN CÍRCULOS, ICONOS, NÚMEROS NI IMÁGENES
    // ==========================================

    const carrerasLineas = carrerasTexto
        .split(/\n+/)
        .map(linea => linea.trim())
        .filter(linea => linea.length > 0);

    const carreras = [];

    // La respuesta de Groq usa: nombre / explicación / línea en blanco.
    // Tomamos solo las primeras 3 carreras, como pide el prompt original.
    for (let i = 0; i < carrerasLineas.length && carreras.length < 3; i += 2) {

        const nombreCarrera = carrerasLineas[i] || "";
        const descripcion = carrerasLineas[i + 1] || "";

        if (nombreCarrera) {
            carreras.push({
                nombre: nombreCarrera,
                descripcion: descripcion
            });
        }
    }

    html += `
        <section class="resultado-bloque carreras-bloque">

            <div class="bloque-cabecera">
                <div class="bloque-numero">2</div>

                <div>
                    <span class="bloque-etiqueta">PARA VOS</span>
                    <h3>Carreras Recomendadas</h3>
                </div>
            </div>

            <p class="bloque-introduccion">
                Opciones que se relacionan con tus intereses,
                fortalezas y respuestas del test.
            </p>

            <div class="carreras-grid">
    `;

    carreras.forEach((carrera, index) => {

        html += `
            <article class="carrera-card">

                <div class="carrera-numero">
                    0${index + 1}
                </div>

                <h4>${carrera.nombre}</h4>

                <p>${carrera.descripcion}</p>

            </article>
        `;

    });

    html += `
            </div>
        </section>
    `;

    // ==========================================
    // 3. DÓNDE ESTUDIAR EN ARGENTINA
    // LOGO SOLO SI EXISTE EN LA CARPETA IMG
    // ==========================================

    const universidadesLineas = universidadesTexto
        .split(/\n+/)
        .map(linea => linea.trim())
        .filter(linea => linea.length > 0);

    const universidades = [];

    for (let i = 0; i < universidadesLineas.length && universidades.length < 3; i += 3) {

        const nombreUniversidad = universidadesLineas[i] || "";
        const ubicacion = universidadesLineas[i + 1] || "";
        const motivo = universidadesLineas[i + 2] || "";

        universidades.push({
            nombre: nombreUniversidad,
            ubicacion: ubicacion,
            motivo: motivo
        });
    }

    html += `
        <section class="resultado-bloque universidades-bloque">

            <div class="bloque-cabecera">
                <div class="bloque-numero">3</div>

                <div>
                    <span class="bloque-etiqueta">TU PRÓXIMO PASO</span>
                    <h3>Dónde Estudiar en Argentina</h3>
                </div>
            </div>

            <p class="bloque-introduccion">
                Algunas instituciones relacionadas con las carreras
                que aparecen en tu perfil.
            </p>

            <div class="universidades-grid">
    `;

    const logosUniversidades = {
        "universidad de buenos aires": "img/UBA.png",
        "universidad nacional de la plata": "img/UNLP.png",
        "universidad nacional de la matanza": "img/UNLam.png",
        "universidad nacional de avellaneda": "img/UNDAV.png",
        "universidad tecnológica nacional": "img/UTN.png",
        "universidad tecnologica nacional": "img/UTN.png",
        "universidad católica argentina": "img/UCA.png",
        "universidad catolica argentina": "img/UCA.png",
        "universidad argentina de la empresa": "img/UADE.png",
        "universidad abierta interamericana": "img/UAI.png",
        "universidad de flores": "img/UFLO.png"
    };

    function obtenerLogoUniversidad(nombreUniversidad) {

        const nombreNormalizado = nombreUniversidad
            .toLowerCase()
            .replace(/\./g, "")
            .trim();

        const encontrada = Object.keys(logosUniversidades).find(nombreClave =>
            nombreNormalizado.includes(nombreClave)
        );

        return encontrada ? logosUniversidades[encontrada] : "";
    }

    function resumirMotivo(motivo) {

        let textoMotivo = motivo
            .replace(/^Por qué estudiarla:\s*/i, "")
            .replace(/^Por que estudiarla:\s*/i, "")
            .replace(/\s+/g, " ")
            .trim();

        // No cortamos a mitad de una oración.
        // Mostramos hasta dos oraciones completas para mantenerlo breve
        // sin dejar textos terminados en "...".
        const oraciones = textoMotivo.match(/[^.!?]+[.!?]+/g);

        if (oraciones && oraciones.length > 0) {
            return oraciones
                .slice(0, 2)
                .join(" ")
                .trim();
        }

        return textoMotivo;
    }

    universidades.forEach(universidad => {

        const logo = obtenerLogoUniversidad(universidad.nombre);
        const ubicacion = universidad.ubicacion.replace(/^Ubicación:\s*/i, "");

        html += `
            <article class="universidad-card ${logo ? "tiene-logo" : "sin-logo"}">

                <div class="universidad-cabecera">

                    ${logo ? `
                        <div class="universidad-logo">
                            <img
                                src="${logo}"
                                alt="Logo de ${universidad.nombre.replace(/"/g, "&quot;")}"
                            >
                        </div>
                    ` : ""}

                    <div class="universidad-contenido">

                        <h4>${universidad.nombre}</h4>

                        <p class="universidad-ubicacion">
                            📍 ${ubicacion}
                        </p>

                    </div>

                </div>

                <div class="universidad-motivo">

                    <strong>¿Por qué?</strong>

                    <span>
                        ${resumirMotivo(universidad.motivo)}
                    </span>

                </div>

            </article>
        `;

    });

    html += `
            </div>
        </section>
    `;

    // ==========================================
    // MOSTRAR RESULTADO
    // ==========================================

    const cargando = document.getElementById("cargando");

    if (cargando) {
        cargando.style.display = "none";
    }

    const caja = document.getElementById("texto-ia");

    if (caja) {
        caja.innerHTML = html;
        caja.style.display = "block";
    }

    const btnImprimir = document.getElementById("btn-imprimir");

    if (btnImprimir) {
        btnImprimir.style.display = "inline-block";
    }

    // Los botones aparecen solamente cuando la respuesta de la IA
    // ya fue generada correctamente.
    const acciones = document.getElementById("acciones-resultados");

    if (acciones) {
        acciones.style.display = "flex";
    }
}


// ==========================================
// 6. CONTROL DE ERRORES Y REINICIO
// ==========================================

function mostrarError() {

    const cargando =
        document.getElementById("cargando");

    if (cargando) {
        cargando.style.display = "none";
    }

    if (elementoHero) {
        elementoHero.style.display = "none";
    }

    if (elementoAcciones) {
        elementoAcciones.style.display = "none";
    }

    if (elementoBotonImprimir) {
        elementoBotonImprimir.style.display = "none";
    }

    const caja =
        document.getElementById("texto-ia");

    if (caja) {
        caja.innerHTML =
            "<p style='color: var(--naranja-quemado); font-weight: bold;'>⚠️ No se pudo conectar con la Inteligencia Artificial. Verificá la consola (F12).</p>";

        caja.style.display = "block";
    }

    // En caso de error, los botones no deben quedar encima
    // del mensaje de error.
    const acciones = document.getElementById("acciones-resultados");

    if (acciones) {
        acciones.style.display = "none";
    }
}


function reiniciarTest() {

    localStorage.removeItem("respuestasGuardadas");

    window.location.href = "index.html";
}


// ==========================================
// 7. EJECUCIÓN INICIAL
// ==========================================

consultarGroq();


// =========================================================
// MENÚ EN LA PÁGINA DE RESULTADOS
// Estas funciones solo controlan los modales de navegación.
// NO modifican el test ni la conexión con Groq.
// =========================================================

function abrirModalResultados(id) {
    const modal = document.getElementById(id);

    if (!modal) return;

    modal.classList.add("activo");
    document.body.classList.add("modal-resultados-abierto");
}

function cerrarModalResultados(id) {
    const modal = document.getElementById(id);

    if (!modal) return;

    modal.classList.remove("activo");
    document.body.classList.remove("modal-resultados-abierto");
}

function abrirModalSobreTestResultados(evento) {
    if (evento) evento.preventDefault();
    abrirModalResultados("modalSobreTestResultados");
}

function abrirModalAreasResultados(evento) {
    if (evento) evento.preventDefault();
    abrirModalResultados("modalAreasResultados");
}

function abrirModalConsejosResultados(evento) {
    if (evento) evento.preventDefault();
    abrirModalResultados("modalConsejosResultados");
}

// Cerrar al hacer clic en el fondo del modal.
document.addEventListener("DOMContentLoaded", function () {

    document.querySelectorAll(".modal-overlay-resultados").forEach(function (overlay) {

        overlay.addEventListener("click", function (evento) {

            if (evento.target === overlay) {
                overlay.classList.remove("activo");
                document.body.classList.remove("modal-resultados-abierto");
            }

        });

    });

    // Cerrar con la tecla Escape.
    document.addEventListener("keydown", function (evento) {

        if (evento.key !== "Escape") return;

        document.querySelectorAll(".modal-overlay-resultados.activo").forEach(function (modal) {
            modal.classList.remove("activo");
        });

        document.body.classList.remove("modal-resultados-abierto");
    });

});
